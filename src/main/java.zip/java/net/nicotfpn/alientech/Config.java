package net.nicotfpn.alientech;

import java.util.List;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.common.ModConfigSpec;

// An example config class. This is not required, but it's a good idea to have one to keep your config organized.
// Demonstrates how to use Neo's config APIs
public class Config {
        private static final ModConfigSpec.Builder BUILDER = new ModConfigSpec.Builder();

        public static final ModConfigSpec.BooleanValue LOG_DIRT_BLOCK = BUILDER
                        .comment("Whether to log the dirt block on common setup")
                        .define("logDirtBlock", true);

        // Client configs...
        public static final ModConfigSpec.IntValue MAGIC_NUMBER = BUILDER
                        .comment("A magic number")
                        .defineInRange("magicNumber", 42, 0, Integer.MAX_VALUE);

        public static final ModConfigSpec.ConfigValue<String> MAGIC_NUMBER_INTRODUCTION = BUILDER
                        .comment("What you want the introduction message to be for the magic number")
                        .define("magicNumberIntroduction", "The magic number is... ");

        public static final ModConfigSpec.ConfigValue<List<? extends String>> ITEM_STRINGS = BUILDER
                        .comment("A list of items to log on common setup.")
                        .defineListAllowEmpty("items", List.of("minecraft:iron_ingot"), () -> "",
                                        Config::validateItemName);

        // SERVER CONFIG (Synced to client)
        public static final ModConfigSpec.Builder SERVER_BUILDER = new ModConfigSpec.Builder();

        // FIX: Renamed and increased capacity for professional standards
        public static final ModConfigSpec.IntValue ANCIENT_BATTERY_CAPACITY = SERVER_BUILDER
                        .comment("Maximum energy capacity for the Ancient Battery")
                        .defineInRange("ancientBatteryCapacity", 10_000_000, 10_000, Integer.MAX_VALUE);

        public static final ModConfigSpec.IntValue CHARGER_CAPACITY = SERVER_BUILDER
                        .comment("Maximum energy capacity for the Ancient Charger")
                        .defineInRange("chargerCapacity", 10_000_000, 10_000, Integer.MAX_VALUE);

        public static final ModConfigSpec.IntValue PHARAOH_SWORD_COST = SERVER_BUILDER
                        .comment("Energy cost per use of the Pharaoh Sword ability")
                        .defineInRange("pharaohSwordCost", 500, 0, Integer.MAX_VALUE);

        public static final ModConfigSpec.IntValue PHARAOH_SWORD_CAPACITY = SERVER_BUILDER
                        .comment("Maximum energy capacity for the Pharaoh Sword")
                        .defineInRange("pharaohSwordCapacity", 1_000_000, 1_000, Integer.MAX_VALUE);

        public static final ModConfigSpec.IntValue PYRAMID_CORE_CAPACITY = SERVER_BUILDER
                        .comment("Maximum energy capacity for the Pyramid Core")
                        .defineInRange("pyramidCoreCapacity", 100_000_000, 1_000_000, Integer.MAX_VALUE);

        public static final ModConfigSpec.IntValue PYRAMID_CORE_GENERATION = SERVER_BUILDER
                        .comment("Energy generation per tick for the Pyramid Core")
                        .defineInRange("pyramidCoreGeneration", 50_000, 100, Integer.MAX_VALUE);

        public static final ModConfigSpec.IntValue PRIMAL_CATALYST_MAX_PROGRESS = SERVER_BUILDER
                        .comment("[LEGACY] Ticks required to craft an Inertial Stability Alloy")
                        .defineInRange("primalCatalystMaxProgress", 72, 1, Integer.MAX_VALUE);

        public static final ModConfigSpec.IntValue PRIMAL_CATALYST_CAPACITY = SERVER_BUILDER
                        .comment("Maximum energy capacity for the Primal Catalyst (FE)")
                        .defineInRange("primalCatalystCapacity", 100_000, 1_000, Integer.MAX_VALUE);

        public static final ModConfigSpec.IntValue PRIMAL_CATALYST_ENERGY_PER_TICK = SERVER_BUILDER
                        .comment("Energy consumed per tick while the Primal Catalyst is processing (FE/t)")
                        .defineInRange("primalCatalystEnergyPerTick", 40, 1, Integer.MAX_VALUE);

        public static final ModConfigSpec.IntValue PRIMAL_CATALYST_PROCESS_TIME = SERVER_BUILDER
                        .comment("Ticks required for the Primal Catalyst to complete one recipe")
                        .defineInRange("primalCatalystProcessTime", 200, 1, Integer.MAX_VALUE);

        public static final ModConfigSpec SERVER_SPEC = SERVER_BUILDER.build();

        static final ModConfigSpec SPEC = BUILDER.build();

        private static boolean validateItemName(final Object obj) {
                return obj instanceof String itemName
                                && BuiltInRegistries.ITEM.containsKey(ResourceLocation.parse(itemName));
        }
}
