package net.nicotfpn.alientech.event;

import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import net.nicotfpn.alientech.AlienTech;
import net.nicotfpn.alientech.block.entity.ModBlockEntities;
import net.nicotfpn.alientech.item.ModItems;
import net.nicotfpn.alientech.item.custom.ActivatedEyeOfHorusItem;
import net.nicotfpn.alientech.item.custom.ItemEnergyStorage;
import net.nicotfpn.alientech.item.custom.PharaohSwordItem;

@EventBusSubscriber(modid = AlienTech.MOD_ID, bus = EventBusSubscriber.Bus.MOD)
public class CommonModEvents {

        @SubscribeEvent
        public static void registerCapabilities(RegisterCapabilitiesEvent event) {
                // Primal Catalyst - Energy Storage
                event.registerBlockEntity(
                                Capabilities.EnergyStorage.BLOCK,
                                ModBlockEntities.PRIMAL_CATALYST_BE.get(),
                                (be, context) -> be.getEnergyStorage(context));

                // Primal Catalyst - ItemHandler (sided access for automation)
                event.registerBlockEntity(
                                Capabilities.ItemHandler.BLOCK,
                                ModBlockEntities.PRIMAL_CATALYST_BE.get(),
                                (be, context) -> be.getItemHandlerForSide(context));

                // Pyramid Core - Energy Storage (output from all sides)
                event.registerBlockEntity(
                                Capabilities.EnergyStorage.BLOCK,
                                ModBlockEntities.PYRAMID_CORE_BE.get(),
                                (be, context) -> be.getEnergyStorage());

                // Pyramid Core - Item Handler
                event.registerBlockEntity(
                                Capabilities.ItemHandler.BLOCK,
                                ModBlockEntities.PYRAMID_CORE_BE.get(),
                                (be, context) -> be.getItemHandler());

                // Ancient Charger - Energy Storage
                event.registerBlockEntity(
                                Capabilities.EnergyStorage.BLOCK,
                                ModBlockEntities.ANCIENT_CHARGER_BE.get(),
                                (be, context) -> be.getEnergyStorage());

                // Ancient Battery - Energy Storage
                event.registerBlockEntity(
                                Capabilities.EnergyStorage.BLOCK,
                                ModBlockEntities.ANCIENT_BATTERY_BE.get(),
                                (be, context) -> be.getEnergyStorage());

                // Ancient Battery - Item Handler
                event.registerBlockEntity(
                                Capabilities.ItemHandler.BLOCK,
                                ModBlockEntities.ANCIENT_BATTERY_BE.get(),
                                (be, context) -> be.getItemHandler());

                // Activated Eye of Horus - Battery (5M FE)
                event.registerItem(
                                Capabilities.EnergyStorage.ITEM,
                                (stack, context) -> new ItemEnergyStorage(
                                                stack,
                                                ActivatedEyeOfHorusItem.MAX_ENERGY, // 5M capacity
                                                50000, // maxReceive
                                                50000 // maxExtract
                                ),
                                ModItems.HORUS_EYE_ACTIVATED.get());

                // Ancient Battery BlockItem - Energy Storage (1M FE)
                // Allows battery to hold energy when in inventory/charger
                event.registerItem(
                                Capabilities.EnergyStorage.ITEM,
                                (stack, context) -> new ItemEnergyStorage(
                                                stack,
                                                1_000_000, // 1M capacity
                                                50000, // maxReceive
                                                50000 // maxExtract
                                ),
                                net.nicotfpn.alientech.registration.AlienBlocks.ANCIENT_BATTERY.asItem());

                // Ancient Charger BlockItem - Energy Storage (10M FE)
                // Allows charger to hold energy when in inventory
                event.registerItem(
                                Capabilities.EnergyStorage.ITEM,
                                (stack, context) -> new ItemEnergyStorage(
                                                stack,
                                                10_000_000, // 10M capacity
                                                100000, // maxReceive
                                                100000 // maxExtract
                                ),
                                net.nicotfpn.alientech.block.ModBlocks.ANCIENT_CHARGER.asItem());

                // Pharaoh Sword - Energy Weapon (1M FE)
                event.registerItem(
                                Capabilities.EnergyStorage.ITEM,
                                (stack, context) -> new ItemEnergyStorage(
                                                stack,
                                                net.nicotfpn.alientech.Config.PHARAOH_SWORD_CAPACITY.get(),
                                                PharaohSwordItem.MAX_TRANSFER,
                                                PharaohSwordItem.MAX_TRANSFER),
                                ModItems.PHARAOH_SWORD.get());
        }
}
