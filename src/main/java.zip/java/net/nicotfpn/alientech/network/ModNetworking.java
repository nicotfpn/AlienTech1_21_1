package net.nicotfpn.alientech.network;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.handling.IPayloadContext;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;
import net.nicotfpn.alientech.AlienTech;

import net.nicotfpn.alientech.block.entity.ISideConfigurable;

/**
 * Registers and handles all network packets for AlienTech mod.
 */
@EventBusSubscriber(modid = AlienTech.MOD_ID, bus = EventBusSubscriber.Bus.MOD)
public class ModNetworking {

    @SubscribeEvent
    public static void register(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar(AlienTech.MOD_ID);

        // Side config packet (client -> server)
        registrar.playToServer(
                SideConfigPacket.TYPE,
                SideConfigPacket.STREAM_CODEC,
                ModNetworking::handleSideConfigServer);

        // Battery mode toggle packet (client -> server)
        /*
         * registrar.playToServer(
         * BatteryModePacket.TYPE,
         * BatteryModePacket.STREAM_CODEC,
         * ModNetworking::handleBatteryModeServer);
         */
    }

    /**
     * Handles side configuration packet on the server.
     */
    private static void handleSideConfigServer(SideConfigPacket packet, IPayloadContext context) {
        context.enqueueWork(() -> {
            ServerPlayer player = (ServerPlayer) context.player();

            if (player.blockPosition().distSqr(packet.pos()) > 64) {
                return;
            }

            BlockEntity blockEntity = player.level().getBlockEntity(packet.pos());
            if (blockEntity instanceof ISideConfigurable configurable) {
                if (packet.reverseDirection()) {
                    configurable.cycleModeReverse(packet.getRelativeSide());
                } else {
                    configurable.cycleMode(packet.getRelativeSide());
                }
            }
        });
    }

    /**
     * Handles battery mode toggle packet on the server.
     * (Deprecated/Removed for Energy Cube style)
     */
    /*
     * private static void handleBatteryModeServer(BatteryModePacket packet,
     * IPayloadContext context) {
     * context.enqueueWork(() -> {
     * ServerPlayer player = (ServerPlayer) context.player();
     * 
     * if (player.blockPosition().distSqr(packet.pos()) > 64) {
     * return;
     * }
     * 
     * BlockEntity blockEntity = player.level().getBlockEntity(packet.pos());
     * if (blockEntity instanceof AncientBatteryBlockEntity battery) {
     * // battery.toggleMode(); // Method removed
     * }
     * });
     * }
     */
}
