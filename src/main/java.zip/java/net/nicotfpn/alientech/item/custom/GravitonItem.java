package net.nicotfpn.alientech.item.custom;

import net.minecraft.world.item.Item;

public class GravitonItem extends Item {
    public GravitonItem(Properties properties) {
        super(properties);
    }
}


