package net.nicotfpn.alientech.block.entity;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.nicotfpn.alientech.AlienTech;
import net.nicotfpn.alientech.block.ModBlocks;

import java.util.function.Supplier;

public class ModBlockEntities {
        public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES = DeferredRegister
                        .create(BuiltInRegistries.BLOCK_ENTITY_TYPE, AlienTech.MOD_ID);

        public static final Supplier<BlockEntityType<PrimalCatalystBlockEntity>> PRIMAL_CATALYST_BE = BLOCK_ENTITIES
                        .register("primal_catalyst_be", () -> BlockEntityType.Builder.of(PrimalCatalystBlockEntity::new,
                                        ModBlocks.PRIMAL_CATALYST.get()).build(null));

        public static final Supplier<BlockEntityType<PyramidCoreBlockEntity>> PYRAMID_CORE_BE = BLOCK_ENTITIES
                        .register("pyramid_core_be", () -> BlockEntityType.Builder.of(PyramidCoreBlockEntity::new,
                                        ModBlocks.PYRAMID_CORE.get()).build(null));

        public static final Supplier<BlockEntityType<AncientChargerBlockEntity>> ANCIENT_CHARGER_BE = BLOCK_ENTITIES
                        .register("ancient_charger_be", () -> BlockEntityType.Builder.of(AncientChargerBlockEntity::new,
                                        ModBlocks.ANCIENT_CHARGER.get()).build(null));

        public static final Supplier<BlockEntityType<AncientBatteryBlockEntity>> ANCIENT_BATTERY_BE = BLOCK_ENTITIES
                        .register("ancient_battery_be", () -> BlockEntityType.Builder.of(AncientBatteryBlockEntity::new,
                                        net.nicotfpn.alientech.registration.AlienBlocks.ANCIENT_BATTERY.get())
                                        .build(null));

        public static void register(IEventBus eventBus) {
                BLOCK_ENTITIES.register(eventBus);
        }
}
