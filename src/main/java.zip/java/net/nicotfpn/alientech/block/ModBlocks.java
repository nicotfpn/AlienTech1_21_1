package net.nicotfpn.alientech.block;

import net.minecraft.util.valueproviders.UniformInt;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.DropExperienceBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.nicotfpn.alientech.AlienTech;
import net.nicotfpn.alientech.block.custom.AncientChargerBlock;
import net.nicotfpn.alientech.block.custom.PrimalCatalystBlock;
import net.nicotfpn.alientech.block.custom.PyramidCoreBlock;
import net.nicotfpn.alientech.item.ModItems;
import java.util.function.Supplier;

public class ModBlocks {
        public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(AlienTech.MOD_ID);

        public static final DeferredBlock<Block> NEUTRION_ORE = registerBlock("neutrion_ore",
                        () -> new DropExperienceBlock(UniformInt.of(2, 4),
                                        BlockBehaviour.Properties.of().strength(3f)
                                                        .requiresCorrectToolForDrops().sound(SoundType.DEEPSLATE)));

        public static final DeferredBlock<Block> NEUTRION_BLOCK = registerBlock("neutrion_block",
                        () -> new Block(BlockBehaviour.Properties.of()
                                        .strength(4f).requiresCorrectToolForDrops().sound(SoundType.AMETHYST)));

        public static final DeferredBlock<Block> PRIMAL_CATALYST = registerBlock("primal_catalyst",
                        () -> new PrimalCatalystBlock(BlockBehaviour.Properties.of()
                                        .mapColor(MapColor.COLOR_PURPLE)
                                        .strength(2.5f)
                                        .sound(SoundType.NETHERITE_BLOCK)
                                        .lightLevel(state -> 7)
                                        .requiresCorrectToolForDrops()));

        public static final DeferredBlock<Block> PYRAMID_CORE = registerBlockCustomItem("pyramid_core",
                        () -> new PyramidCoreBlock(BlockBehaviour.Properties.of()
                                        .mapColor(MapColor.COLOR_YELLOW)
                                        .strength(3f)
                                        .sound(SoundType.STONE)
                                        .lightLevel(state -> 8)
                                        .requiresCorrectToolForDrops()),
                        block -> new net.nicotfpn.alientech.item.custom.PyramidCoreBlockItem(block,
                                        new Item.Properties()));

        public static final DeferredBlock<Block> ANCIENT_CHARGER = registerBlockCustomItem("ancient_charger",
                        () -> new AncientChargerBlock(BlockBehaviour.Properties.of()
                                        .mapColor(MapColor.GOLD)
                                        .strength(3f)
                                        .sound(SoundType.NETHERITE_BLOCK)
                                        .lightLevel(state -> 5)
                                        .requiresCorrectToolForDrops()),
                        // Custom BlockItem for energy tooltip
                        block -> new net.nicotfpn.alientech.item.custom.AncientChargerBlockItem(block,
                                        new Item.Properties()));

        /*
         * public static final DeferredBlock<Block> ANCIENT_BATTERY =
         * registerBlockCustomItem("ancient_battery",
         * () -> new AncientBatteryBlock(BlockBehaviour.Properties.of()
         * .mapColor(MapColor.GOLD)
         * .strength(3f)
         * .sound(SoundType.NETHERITE_BLOCK)
         * .lightLevel(state -> 3)
         * .requiresCorrectToolForDrops()),
         * block -> new
         * net.nicotfpn.alientech.item.custom.AncientBatteryBlockItem(block,
         * new Item.Properties().stacksTo(1)));
         */

        private static <T extends Block> DeferredBlock<T> registerBlock(String name, Supplier<T> block) {
                DeferredBlock<T> toReturn = BLOCKS.register(name, block);
                registerBlockItem(name, toReturn);
                return toReturn;
        }

        private static <T extends Block> void registerBlockItem(String name, DeferredBlock<T> block) {
                ModItems.ITEMS.register(name, () -> new BlockItem(block.get(), new Item.Properties()));
        }

        private static <T extends Block> DeferredBlock<T> registerBlockCustomItem(String name, Supplier<T> block,
                        java.util.function.Function<T, BlockItem> itemFactory) {
                DeferredBlock<T> toReturn = BLOCKS.register(name, block);
                ModItems.ITEMS.register(name, () -> itemFactory.apply(toReturn.get()));
                return toReturn;
        }

        public static void register(IEventBus eventBus) {
                BLOCKS.register(eventBus);
        }
}
