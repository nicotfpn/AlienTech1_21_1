package net.nicotfpn.alientech.block.entity.base;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.Containers;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.items.IItemHandler;
import net.neoforged.neoforge.items.ItemStackHandler;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.EnumMap;
import java.util.Map;

/**
 * Abstract base class for all processing machines in AlienTech.
 * Provides a complete, reusable framework for machines with:
 * <ul>
 * <li>Configurable inventory (any number of slots)</li>
 * <li>Hybrid energy (FE) + fuel (coal block) power system</li>
 * <li>Progress tracking with automatic ContainerData sync</li>
 * <li>Sided item handler for automation (hoppers, pipes)</li>
 * <li>Auto-push outputs to adjacent inventories</li>
 * <li>Full NBT persistence</li>
 * </ul>
 *
 * Subclasses only need to implement the abstract hooks to define
 * machine-specific behavior (recipes, slot rules, costs, etc).
 */
public abstract class AbstractMachineBlockEntity extends AlienElectricBlockEntity {

    // ==================== Constants ====================
    private static final int AUTO_PUSH_INTERVAL = 10;
    private static final int COAL_BLOCK_BURN_TIME = 16_000;

    // ==================== Inventory ====================
    protected final ItemStackHandler itemHandler;

    // ==================== Processing State ====================
    protected int progress = 0;
    protected int burnTime = 0;
    protected int maxBurnTime = 0;

    // ==================== Timers ====================
    private int autoPushTimer = 0;

    // ==================== Sided Handler Cache ====================
    private final Map<Direction, IItemHandler> sidedHandlerCache = new EnumMap<>(Direction.class);

    // ==================== Container Data (6 values synced to client)
    // ====================
    protected final ContainerData data = new ContainerData() {
        @Override
        public int get(int index) {
            return switch (index) {
                case 0 -> progress;
                case 1 -> getProcessTime();
                case 2 -> burnTime;
                case 3 -> maxBurnTime;
                case 4 -> energyStorage.getEnergyStored();
                case 5 -> energyStorage.getMaxEnergyStored();
                default -> 0;
            };
        }

        @Override
        public void set(int index, int value) {
            switch (index) {
                case 0 -> progress = value;
                // case 1: maxProgress is derived from getProcessTime(), not settable
                case 2 -> burnTime = value;
                case 3 -> maxBurnTime = value;
                // case 4, 5: energy is managed by energyStorage
            }
        }

        @Override
        public int getCount() {
            return 6;
        }
    };

    // ==================== Constructor ====================

    public AbstractMachineBlockEntity(BlockEntityType<?> type, BlockPos pos, BlockState state,
            int energyCapacity, int maxReceive, int maxExtract, int slotCount) {
        super(type, pos, state, energyCapacity, maxReceive, maxExtract);
        this.itemHandler = new ItemStackHandler(slotCount) {
            @Override
            protected void onContentsChanged(int slot) {
                setChanged();
                markInventoryDirty();
            }

            @Override
            public boolean isItemValid(int slot, @NotNull ItemStack stack) {
                return AbstractMachineBlockEntity.this.isItemValidForSlot(slot, stack);
            }
        };
    }

    // ==================== Abstract Hooks (subclasses MUST implement)
    // ====================

    /**
     * Check if a valid recipe exists for the current inventory contents.
     * Should also verify that the output slot has space.
     */
    protected abstract boolean hasRecipe();

    /**
     * Execute the craft: consume inputs and place result in output.
     * Called only when progress reaches getProcessTime() and hasRecipe() is true.
     */
    protected abstract void craft();

    /**
     * Energy cost per tick while processing.
     */
    protected abstract int getEnergyCost();

    /**
     * Total ticks required to complete one crafting operation.
     */
    protected abstract int getProcessTime();

    /**
     * Whether the given item can be inserted into the given slot from the given
     * side.
     * 
     * @param slot  the inventory slot index
     * @param stack the item being inserted
     * @param side  the direction from which insertion is attempted (null =
     *              internal)
     */
    protected abstract boolean canInsert(int slot, @NotNull ItemStack stack, @Nullable Direction side);

    /**
     * Whether items can be extracted from the given slot from the given side.
     * 
     * @param slot the inventory slot index
     * @param side the direction from which extraction is attempted (null =
     *             internal)
     */
    protected abstract boolean canExtract(int slot, @Nullable Direction side);

    /**
     * Get the slot index used for fuel (coal blocks). Return -1 if no fuel slot.
     */
    protected abstract int getFuelSlot();

    /**
     * Get the slot indices used for output. Used for auto-push.
     */
    protected abstract int[] getOutputSlots();

    // ==================== Optional Hooks ====================

    /**
     * Validate whether an item can go into a specific slot (used by
     * ItemStackHandler).
     * Default: delegates to canInsert with null side.
     */
    protected boolean isItemValidForSlot(int slot, @NotNull ItemStack stack) {
        return canInsert(slot, stack, null);
    }

    /**
     * Check if a given ItemStack is valid fuel for this machine.
     * Default: coal_block only.
     */
    protected boolean isValidFuel(@NotNull ItemStack stack) {
        return stack.is(Items.COAL_BLOCK);
    }

    /**
     * Get the burn time for a fuel item.
     * Default: 16000 ticks for coal_block.
     */
    protected int getFuelBurnTime(@NotNull ItemStack stack) {
        if (stack.is(Items.COAL_BLOCK)) {
            return COAL_BLOCK_BURN_TIME;
        }
        return 0;
    }

    // ==================== Server Tick Logic ====================

    @Override
    protected void onUpdateServer() {
        super.onUpdateServer(); // handles sync channels from AlienElectricBlockEntity

        boolean wasProcessing = progress > 0;

        // Step 1: Try to consume fuel if we have no burn time and no energy
        tryConsumeFuel();

        // Step 2: Check if we can process
        if (hasRecipe()) {
            if (hasPower()) {
                // Consume power
                consumePower();

                // Advance progress
                progress++;
                setChanged();

                // Check completion
                if (progress >= getProcessTime()) {
                    craft();
                    progress = 0;
                    markInventoryDirty();
                }
            } else {
                // No power available - reset progress
                if (progress > 0) {
                    progress = 0;
                    setChanged();
                }
            }
        } else {
            // No valid recipe - reset progress
            if (progress > 0) {
                progress = 0;
                setChanged();
            }
        }

        // Step 3: Tick down burn time
        if (burnTime > 0) {
            burnTime--;
            setChanged();
        }

        // Step 4: Auto-push outputs
        autoPushTimer++;
        if (autoPushTimer >= AUTO_PUSH_INTERVAL) {
            autoPushTimer = 0;
            autoPushOutputs();
        }
    }

    /**
     * Check if the machine currently has power (energy or burning fuel).
     */
    protected boolean hasPower() {
        return energyStorage.getEnergyStored() >= getEnergyCost() || burnTime > 0;
    }

    /**
     * Consume power with priority: energy first, then fuel.
     */
    private void consumePower() {
        int cost = getEnergyCost();
        if (energyStorage.getEnergyStored() >= cost) {
            // Priority 1: Use FE energy
            energyStorage.extractEnergy(cost, false);
        }
        // If not enough FE, fuel burn time is already ticking down passively
        // (no additional consumption needed - burn time was started in tryConsumeFuel)
    }

    /**
     * Try to consume a fuel item from the fuel slot to start burning.
     */
    private void tryConsumeFuel() {
        int fuelSlot = getFuelSlot();
        if (fuelSlot < 0)
            return; // No fuel slot

        // Only consume fuel if: we have no burn time, not enough energy, and have a
        // recipe
        if (burnTime <= 0 && energyStorage.getEnergyStored() < getEnergyCost() && hasRecipe()) {
            ItemStack fuelStack = itemHandler.getStackInSlot(fuelSlot);
            if (!fuelStack.isEmpty() && isValidFuel(fuelStack)) {
                int fuelTime = getFuelBurnTime(fuelStack);
                if (fuelTime > 0) {
                    burnTime = fuelTime;
                    maxBurnTime = fuelTime;
                    itemHandler.extractItem(fuelSlot, 1, false);
                    markInventoryDirty();
                }
            }
        }
    }

    /**
     * Auto-push items from output slots to adjacent inventories.
     */
    private void autoPushOutputs() {
        int[] outputSlots = getOutputSlots();
        if (outputSlots == null || outputSlots.length == 0)
            return;

        for (int outputSlot : outputSlots) {
            ItemStack outputStack = itemHandler.getStackInSlot(outputSlot);
            if (outputStack.isEmpty())
                continue;

            for (Direction direction : Direction.values()) {
                if (!canExtract(outputSlot, direction))
                    continue;

                BlockPos adjacentPos = worldPosition.relative(direction);
                if (level == null || !level.isLoaded(adjacentPos))
                    continue;

                IItemHandler adjacentHandler = level.getCapability(
                        Capabilities.ItemHandler.BLOCK, adjacentPos, direction.getOpposite());
                if (adjacentHandler == null)
                    continue;

                ItemStack toInsert = outputStack.copy();
                for (int slot = 0; slot < adjacentHandler.getSlots() && !toInsert.isEmpty(); slot++) {
                    toInsert = adjacentHandler.insertItem(slot, toInsert, false);
                }

                if (toInsert.getCount() < outputStack.getCount()) {
                    int pushed = outputStack.getCount() - toInsert.getCount();
                    itemHandler.extractItem(outputSlot, pushed, false);
                    outputStack = itemHandler.getStackInSlot(outputSlot);
                    if (outputStack.isEmpty())
                        break;
                }
            }
        }
    }

    // ==================== Inventory Access ====================

    public ItemStackHandler getItemHandler() {
        return itemHandler;
    }

    /**
     * Get a sided item handler for capability exposure.
     * Returns the raw handler for null side (internal access),
     * or a filtered wrapper for directional access.
     */
    public IItemHandler getItemHandlerForSide(@Nullable Direction side) {
        if (side == null)
            return itemHandler;
        return sidedHandlerCache.computeIfAbsent(side, s -> new SidedItemHandler(s));
    }

    /**
     * Invalidate the sided handler cache (call when side config changes).
     */
    protected void invalidateSidedCache() {
        sidedHandlerCache.clear();
    }

    // ==================== NBT Persistence ====================

    @Override
    public void saveAdditional(@NotNull CompoundTag tag, @NotNull HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.put("Inventory", itemHandler.serializeNBT(registries));
        tag.putInt("Progress", progress);
        tag.putInt("BurnTime", burnTime);
        tag.putInt("MaxBurnTime", maxBurnTime);
    }

    @Override
    public void loadAdditional(@NotNull CompoundTag tag, @NotNull HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        if (tag.contains("Inventory")) {
            itemHandler.deserializeNBT(registries, tag.getCompound("Inventory"));
        }
        progress = tag.getInt("Progress");
        burnTime = tag.getInt("BurnTime");
        maxBurnTime = tag.getInt("MaxBurnTime");
    }

    // ==================== Block Removal ====================

    /**
     * Drop all inventory contents when block is broken.
     */
    public void drops() {
        SimpleContainer inventory = new SimpleContainer(itemHandler.getSlots());
        for (int i = 0; i < itemHandler.getSlots(); i++) {
            inventory.setItem(i, itemHandler.getStackInSlot(i));
        }
        if (level != null) {
            Containers.dropContents(level, worldPosition, inventory);
        }
    }

    // ==================== Container Data Access ====================

    public ContainerData getContainerData() {
        return data;
    }

    // ==================== Sided Item Handler Wrapper ====================

    /**
     * A wrapper around the internal ItemStackHandler that enforces
     * per-slot, per-direction insertion/extraction rules defined by
     * the machine's canInsert() and canExtract() hooks.
     */
    private class SidedItemHandler implements IItemHandler {
        private final Direction side;

        public SidedItemHandler(Direction side) {
            this.side = side;
        }

        @Override
        public int getSlots() {
            return itemHandler.getSlots();
        }

        @Override
        public @NotNull ItemStack getStackInSlot(int slot) {
            return itemHandler.getStackInSlot(slot);
        }

        @Override
        public @NotNull ItemStack insertItem(int slot, @NotNull ItemStack stack, boolean simulate) {
            if (!canInsert(slot, stack, side))
                return stack;
            return itemHandler.insertItem(slot, stack, simulate);
        }

        @Override
        public @NotNull ItemStack extractItem(int slot, int amount, boolean simulate) {
            if (!canExtract(slot, side))
                return ItemStack.EMPTY;
            return itemHandler.extractItem(slot, amount, simulate);
        }

        @Override
        public int getSlotLimit(int slot) {
            return itemHandler.getSlotLimit(slot);
        }

        @Override
        public boolean isItemValid(int slot, @NotNull ItemStack stack) {
            return canInsert(slot, stack, side);
        }
    }
}
