package net.nicotfpn.alientech.block.entity;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.Containers;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.items.ItemStackHandler;

import net.nicotfpn.alientech.Config;
import net.nicotfpn.alientech.block.entity.base.AlienElectricBlockEntity;
import net.nicotfpn.alientech.item.ModItems;
import net.nicotfpn.alientech.screen.PyramidCoreMenu;
import net.nicotfpn.alientech.util.EnergyUtils;
import net.nicotfpn.alientech.util.PyramidStructureHandler;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * Pyramid Core - Central power generator.
 * FIX [H1]: Extends AlienElectricBlockEntity (standardized hierarchy).
 * FIX [H6]: Capped energy accumulator.
 * FIX [C4]: Uses base class safe load.
 * FIX [C2]: Throttled sync.
 */
public class PyramidCoreBlockEntity extends AlienElectricBlockEntity {

    private static final int FUEL_SLOT = 0;
    private static final int STRUCTURE_CHECK_INTERVAL = 100;
    private static final long ENERGY_PER_GRAVITON = 250_000L;

    private int cachedGenerationRate;
    private long energyAccumulator = 0;

    private final ItemStackHandler itemHandler = new ItemStackHandler(1) {
        @Override
        protected void onContentsChanged(int slot) {
            setChanged();
            markInventoryDirty(); // Immediate sync for item changes
        }

        @Override
        public boolean isItemValid(int slot, ItemStack stack) {
            return stack.is(ModItems.GRAVITON.get());
        }

        @Override
        public int getSlotLimit(int slot) {
            return 64;
        }
    };

    private boolean isActive = false;
    private boolean structureValid = false;
    private long lastStructureCheck = 0;
    private int totalEnergyGenerated = 0;

    protected final ContainerData containerData = new ContainerData() {
        @Override
        public int get(int index) {
            return switch (index) {
                case 0 -> energyStorage.getEnergyStored() & 0xFFFF;
                case 1 -> (energyStorage.getEnergyStored() >> 16) & 0xFFFF;
                case 2 -> isActive ? 1 : 0;
                case 3 -> itemHandler.getStackInSlot(FUEL_SLOT).getCount();
                default -> 0; // FIX [C7]: Implicit bounds check
            };
        }

        @Override
        public void set(int index, int value) {
        }

        @Override
        public int getCount() {
            return 4;
        }
    };

    public PyramidCoreBlockEntity(BlockPos pos, BlockState blockState) {
        // FIX [M1]: Use Config
        super(ModBlockEntities.PYRAMID_CORE_BE.get(), pos, blockState,
                Config.PYRAMID_CORE_CAPACITY.get(), // Capacity
                Config.PYRAMID_CORE_CAPACITY.get(), // Receive (Full)
                Config.PYRAMID_CORE_CAPACITY.get()); // Extract (Full) - Burst mode

        this.cachedGenerationRate = Config.PYRAMID_CORE_GENERATION.get();
    }

    public static <T extends net.minecraft.world.level.block.entity.BlockEntity> void tick(Level level, BlockPos pos,
            BlockState blockState, T blockEntity) {
        if (level.isClientSide)
            return;
        if (blockEntity instanceof PyramidCoreBlockEntity core) {
            core.onUpdateServer();
        }
    }

    @Override
    protected void onUpdateServer() {
        super.onUpdateServer(); // Throttled sync

        long currentTime = level.getGameTime();

        // Structure Validation
        if (currentTime - lastStructureCheck >= STRUCTURE_CHECK_INTERVAL) {
            boolean wasValid = structureValid;
            structureValid = PyramidStructureHandler.isValidPyramid(level, worldPosition);
            lastStructureCheck = currentTime;

            if (wasValid != structureValid) {
                setChanged();
                markForSync();
            }

            if (!structureValid && isActive) {
                setActive(false);
            }
        }

        // Logic Check
        ItemStack fuelStack = itemHandler.getStackInSlot(FUEL_SLOT);
        boolean hasFuel = !fuelStack.isEmpty() && fuelStack.is(ModItems.GRAVITON.get());

        if ((!hasFuel || !structureValid) && isActive) {
            setActive(false);
        }

        // Generation
        if (isActive && energyStorage.getEnergyStored() < energyStorage.getMaxEnergyStored()) {
            int generationRate = cachedGenerationRate;
            int generated = energyStorage.receiveEnergy(generationRate, false);

            if (generated > 0) {
                totalEnergyGenerated += generated;
                energyAccumulator += generated;

                // FIX [H6]: Cap accumulation
                if (energyAccumulator > ENERGY_PER_GRAVITON * 2) {
                    energyAccumulator = ENERGY_PER_GRAVITON * 2;
                }

                if (energyAccumulator >= ENERGY_PER_GRAVITON) {
                    int fuelToConsume = (int) (energyAccumulator / ENERGY_PER_GRAVITON);
                    if (fuelToConsume > 0) {
                        energyAccumulator -= (long) fuelToConsume * ENERGY_PER_GRAVITON;
                        fuelStack.shrink(fuelToConsume);
                        if (fuelStack.isEmpty()) {
                            itemHandler.setStackInSlot(FUEL_SLOT, ItemStack.EMPTY);
                            setActive(false);
                            energyAccumulator = 0;
                        } else {
                            itemHandler.setStackInSlot(FUEL_SLOT, fuelStack);
                        }
                    }
                }
            }
        }

        // Burst Transfer
        if (energyStorage.getEnergyStored() > 0) {
            for (Direction dir : Direction.values()) {
                BlockPos target = worldPosition.relative(dir);
                // FIX [H3]: Check loaded
                if (level.isLoaded(target)) {
                    EnergyUtils.pushToPosition(level, target, dir.getOpposite(), energyStorage,
                            energyStorage.getMaxEnergyStored());
                }
            }
        }
    }

    public void setActive(boolean active) {
        if (this.isActive != active) {
            this.isActive = active;
            setChanged();
            markForSync();
        }
    }

    // ... getters ...
    public boolean isActive() {
        return isActive;
    }

    public ItemStackHandler getItemHandler() {
        return itemHandler;
    }

    public int getTotalEnergyGenerated() {
        return totalEnergyGenerated;
    }

    public boolean isStructureValid() {
        return structureValid;
    }

    @Override
    public Component getDisplayName() {
        return Component.translatable("block.alientech.pyramid_core");
    }

    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int id, Inventory pInv, Player pPlayer) {
        return new PyramidCoreMenu(id, pInv, this, containerData);
    }

    // Compatibility methods
    public void drops() {
        SimpleContainer inventory = new SimpleContainer(itemHandler.getSlots());
        for (int i = 0; i < itemHandler.getSlots(); i++) {
            inventory.setItem(i, itemHandler.getStackInSlot(i));
        }
        Containers.dropContents(this.level, this.worldPosition, inventory);
    }

    public int getMaxEnergy() {
        return energyStorage.getMaxEnergyStored();
    }

    public void deactivatePyramid() {
        setActive(false);
    }

    public boolean activatePyramid() {
        if (PyramidStructureHandler.isValidPyramid(level, worldPosition)) {
            setActive(true);
            return true;
        }
        return false;
    }

    // Persistence
    @Override
    public void loadAdditional(@NotNull CompoundTag tag, @NotNull HolderLookup.Provider provider) {
        super.loadAdditional(tag, provider);
        itemHandler.deserializeNBT(provider, tag.getCompound("ItemHandler"));
        isActive = tag.getBoolean("IsActive");
        structureValid = tag.getBoolean("StructureValid");
        lastStructureCheck = tag.getLong("LastStructureCheck");
        totalEnergyGenerated = tag.getInt("TotalEnergyGenerated");
        energyAccumulator = tag.getLong("EnergyAccumulator");
    }

    @Override
    public void saveAdditional(@NotNull CompoundTag tag, @NotNull HolderLookup.Provider provider) {
        super.saveAdditional(tag, provider);
        tag.put("ItemHandler", itemHandler.serializeNBT(provider));
        tag.putBoolean("IsActive", isActive);
        tag.putBoolean("StructureValid", structureValid);
        tag.putLong("LastStructureCheck", lastStructureCheck);
        tag.putInt("TotalEnergyGenerated", totalEnergyGenerated);
        tag.putLong("EnergyAccumulator", energyAccumulator);
    }
}
// ✅ CORRIGIDO: C2, C4, C7, H1, H3, H6, M1
