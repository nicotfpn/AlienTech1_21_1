package net.nicotfpn.alientech.block.entity;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.RecipeHolder;
import net.minecraft.world.item.crafting.RecipeManager;
import net.minecraft.world.level.block.state.BlockState;
import net.nicotfpn.alientech.Config;
import net.nicotfpn.alientech.block.entity.base.AbstractMachineBlockEntity;
import net.nicotfpn.alientech.recipe.ModRecipes;
import net.nicotfpn.alientech.recipe.PrimalCatalystRecipe;
import net.nicotfpn.alientech.recipe.PrimalCatalystRecipeInput;
import net.nicotfpn.alientech.screen.PrimalCatalystMenu;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;

/**
 * Primal Catalyst - A 3-input processing machine with hybrid energy/fuel
 * support.
 *
 * Slot layout:
 * 0, 1, 2 = Input slots
 * 3 = Fuel slot (coal_block only)
 * 4 = Output slot
 *
 * Sided automation:
 * TOP → insert into input slots (0, 1, 2)
 * SIDES → insert into fuel slot (3)
 * BOTTOM → extract from output slot (4)
 *
 * Built on the AbstractMachineBlockEntity framework for maximum reusability.
 */
public class PrimalCatalystBlockEntity extends AbstractMachineBlockEntity {

    // ==================== Slot Constants ====================
    public static final int INPUT_SLOT_1 = 0;
    public static final int INPUT_SLOT_2 = 1;
    public static final int INPUT_SLOT_3 = 2;
    public static final int FUEL_SLOT = 3;
    public static final int OUTPUT_SLOT = 4;
    private static final int SLOT_COUNT = 5;

    // ==================== Energy Constants ====================
    private static final int DEFAULT_CAPACITY = 100_000;
    private static final int MAX_RECEIVE = 1_000;
    private static final int MAX_EXTRACT = 0; // Machine doesn't export energy

    // ==================== Cached Recipe ====================
    private PrimalCatalystRecipe cachedRecipe = null;
    private boolean recipeCacheDirty = true;

    public PrimalCatalystBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.PRIMAL_CATALYST_BE.get(), pos, state,
                DEFAULT_CAPACITY, MAX_RECEIVE, MAX_EXTRACT, SLOT_COUNT);
    }

    // ==================== Framework Hook Implementations ====================

    @Override
    protected boolean hasRecipe() {
        if (level == null)
            return false;

        // Invalidate cache when inventory changes
        if (recipeCacheDirty) {
            cachedRecipe = findRecipe();
            recipeCacheDirty = false;
        }

        if (cachedRecipe == null)
            return false;

        // Check output slot has space
        ItemStack outputStack = itemHandler.getStackInSlot(OUTPUT_SLOT);
        ItemStack recipeResult = cachedRecipe.getResult();

        if (outputStack.isEmpty())
            return true;
        if (!ItemStack.isSameItemSameComponents(outputStack, recipeResult))
            return false;
        return outputStack.getCount() + recipeResult.getCount() <= outputStack.getMaxStackSize();
    }

    @Override
    protected void craft() {
        if (cachedRecipe == null)
            return;

        // Consume one of each input
        itemHandler.extractItem(INPUT_SLOT_1, 1, false);
        itemHandler.extractItem(INPUT_SLOT_2, 1, false);
        itemHandler.extractItem(INPUT_SLOT_3, 1, false);

        // Produce output
        ItemStack result = cachedRecipe.getResult();
        ItemStack currentOutput = itemHandler.getStackInSlot(OUTPUT_SLOT);

        if (currentOutput.isEmpty()) {
            itemHandler.setStackInSlot(OUTPUT_SLOT, result.copy());
        } else {
            currentOutput.grow(result.getCount());
        }

        // Invalidate recipe cache after crafting
        recipeCacheDirty = true;
    }

    @Override
    protected int getEnergyCost() {
        int baseCost = Config.PRIMAL_CATALYST_ENERGY_PER_TICK.get();
        if (cachedRecipe != null) {
            return Math.round(baseCost * cachedRecipe.getEnergyModifier());
        }
        return baseCost;
    }

    @Override
    protected int getProcessTime() {
        return Config.PRIMAL_CATALYST_PROCESS_TIME.get();
    }

    @Override
    protected boolean canInsert(int slot, @NotNull ItemStack stack, @Nullable Direction side) {
        if (side == null) {
            // Internal access (GUI): allow inputs and fuel, deny output
            return slot != OUTPUT_SLOT;
        }

        return switch (side) {
            case UP -> slot >= INPUT_SLOT_1 && slot <= INPUT_SLOT_3; // TOP: inputs only
            case DOWN -> false; // BOTTOM: extract only, no insert
            default -> slot == FUEL_SLOT && isValidFuel(stack); // SIDES: fuel only
        };
    }

    @Override
    protected boolean canExtract(int slot, @Nullable Direction side) {
        if (side == null)
            return true; // Internal access always allowed
        return side == Direction.DOWN && slot == OUTPUT_SLOT; // BOTTOM: output only
    }

    @Override
    protected int getFuelSlot() {
        return FUEL_SLOT;
    }

    @Override
    protected int[] getOutputSlots() {
        return new int[] { OUTPUT_SLOT };
    }

    @Override
    protected boolean isItemValidForSlot(int slot, @NotNull ItemStack stack) {
        if (slot == OUTPUT_SLOT)
            return false;
        if (slot == FUEL_SLOT)
            return isValidFuel(stack);
        return true; // Input slots accept anything (recipe validation happens at craft time)
    }

    @Override
    protected boolean isValidFuel(@NotNull ItemStack stack) {
        return stack.is(Items.COAL_BLOCK);
    }

    // ==================== Recipe Lookup ====================

    private PrimalCatalystRecipe findRecipe() {
        if (level == null)
            return null;

        PrimalCatalystRecipeInput input = new PrimalCatalystRecipeInput(
                itemHandler.getStackInSlot(INPUT_SLOT_1),
                itemHandler.getStackInSlot(INPUT_SLOT_2),
                itemHandler.getStackInSlot(INPUT_SLOT_3));

        RecipeManager recipeManager = level.getRecipeManager();
        Optional<RecipeHolder<PrimalCatalystRecipe>> recipe = recipeManager
                .getRecipeFor(ModRecipes.PRIMAL_CATALYST_TYPE.get(), input, level);

        return recipe.map(RecipeHolder::value).orElse(null);
    }

    /**
     * Mark recipe cache as dirty when inventory changes.
     * Called by the ItemStackHandler's onContentsChanged.
     */
    @Override
    protected void onUpdateServer() {
        // The recipeCacheDirty flag is set via onContentsChanged -> markInventoryDirty
        // We piggyback on that: whenever inventory is dirty, recipe cache should be too
        super.onUpdateServer();
    }

    // Override to invalidate recipe cache when inventory changes
    @Override
    protected void markInventoryDirty() {
        super.markInventoryDirty();
        recipeCacheDirty = true;
    }

    // ==================== Menu Provider ====================

    @Override
    public @NotNull Component getDisplayName() {
        return Component.translatable("block.alientech.primal_catalyst");
    }

    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int containerId, @NotNull Inventory playerInventory,
            @NotNull Player player) {
        return new PrimalCatalystMenu(containerId, playerInventory, this, this.data);
    }
}
